#define LED_PIN 2
#define PIN_SENSOR A0
void tareaLed( void * parametro ) {
  pinMode( LED_PIN , OUTPUT );
  while (1) {
    digitalWrite( LED_PIN , HIGH );
    vTaskDelay( 500 / portTICK_PERIOD_MS );

    digitalWrite( LED_PIN , LOW );
    vTaskDelay( 500 / portTICK_PERIOD_MS );
  }
}
void tareaSensor( void * parametro ) {
  while (1) {
    int valorSensor = analogRead( PIN_SENSOR );
    Serial.printf("Valor del sensor virtual: %d\n", valorSensor);
    vTaskDelay( 1000 / portTICK_PERIOD_MS );
  }
}
void setup() {
  Serial.begin(115200);

  xTaskCreate(tareaLed, "Tarea LED", 1024, NULL, 1, NULL);
  xTaskCreate(tareaSensor, "Tarea Sensor", 1024, NULL, 1, NULL);

  Serial.println("FreeRTOS ejecutándose en Wokwi");
}
void loop() { }
